import React from 'react';
import styled from 'styled-components';
import { FiDownload, FiRefreshCw } from 'react-icons/fi';

const ResultsContainer = styled.div`
  padding: 20px;
`;

const ResultsHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 30px;
`;

const Title = styled.h2`
  color: var(--primary-color);
  margin: 0;
`;

const ButtonGroup = styled.div`
  display: flex;
  gap: 10px;
`;

const Button = styled.a`
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background-color: var(--primary-color);
  color: white;
  padding: 10px 20px;
  border-radius: 5px;
  text-decoration: none;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    background-color: #c04b6e;
    transform: translateY(-2px);
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  }
`;

const ResetButton = styled.button`
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background-color: var(--secondary-color);
  color: var(--dark-color);
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    background-color: #f0a5bd;
  }
`;

const Section = styled.div`
  margin-bottom: 30px;
  background-color: white;
  border-radius: 10px;
  padding: 20px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
`;

const SectionTitle = styled.h3`
  color: var(--primary-color);
  margin-top: 0;
  margin-bottom: 15px;
  border-bottom: 2px solid var(--secondary-color);
  padding-bottom: 10px;
`;

const FeatureList = styled.ul`
  list-style-type: none;
  padding: 0;
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 10px;
`;

const FeatureItem = styled.li`
  padding: 10px;
  background-color: #f9f9f9;
  border-radius: 5px;
  
  strong {
    color: var(--primary-color);
  }
`;

const RecommendationList = styled.ul`
  list-style-type: none;
  padding: 0;
`;

const RecommendationItem = styled.li`
  margin-bottom: 15px;
  padding: 15px;
  background-color: #f9f9f9;
  border-radius: 5px;
  border-left: 4px solid var(--primary-color);
  
  strong {
    color: var(--primary-color);
    display: block;
    margin-bottom: 5px;
  }
`;

const CelebritySection = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  
  @media (min-width: 768px) {
    flex-direction: row;
    text-align: left;
    gap: 20px;
  }
`;

const CelebrityImage = styled.img`
  width: 150px;
  height: 150px;
  border-radius: 50%;
  object-fit: cover;
  margin-bottom: 15px;
  
  @media (min-width: 768px) {
    margin-bottom: 0;
  }
`;

const CelebrityInfo = styled.div`
  flex: 1;
`;

const CelebrityName = styled.h4`
  color: var(--primary-color);
  margin-top: 0;
  margin-bottom: 10px;
  font-size: 18px;
`;

const CelebrityStyle = styled.p`
  margin: 0;
`;

const Results = ({ results, onReset }) => {
  const { name, features, recommendations, celebrity, report_url } = results;
  
  return (
    <ResultsContainer>
      <ResultsHeader>
        <Title>Your Makeup Recommendations</Title>
        <ButtonGroup>
          <Button href={report_url} target="_blank" rel="noopener noreferrer">
            <FiDownload /> Download Report
          </Button>
          <ResetButton onClick={onReset}>
            <FiRefreshCw /> Start Over
          </ResetButton>
        </ButtonGroup>
      </ResultsHeader>
      
      <Section>
        <SectionTitle>Facial Features</SectionTitle>
        <FeatureList>
          {Object.entries(features).map(([key, value]) => (
            <FeatureItem key={key}>
              <strong>{key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}:</strong> {value}
            </FeatureItem>
          ))}
        </FeatureList>
      </Section>
      
      <Section>
        <SectionTitle>Makeup Recommendations</SectionTitle>
        <RecommendationList>
          {Object.entries(recommendations).map(([key, value]) => (
            <RecommendationItem key={key}>
              <strong>{key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</strong>
              {value}
            </RecommendationItem>
          ))}
        </RecommendationList>
      </Section>
      
      <Section>
        <SectionTitle>Celebrity Lookalike</SectionTitle>
        <CelebritySection>
          <CelebrityImage src={celebrity.image} alt={celebrity.name} />
          <CelebrityInfo>
            <CelebrityName>You resemble {celebrity.name}</CelebrityName>
            <CelebrityStyle>
              <strong>Recommended Style:</strong> {celebrity.makeup_style}
            </CelebrityStyle>
          </CelebrityInfo>
        </CelebritySection>
      </Section>
    </ResultsContainer>
  );
};

export default Results; 