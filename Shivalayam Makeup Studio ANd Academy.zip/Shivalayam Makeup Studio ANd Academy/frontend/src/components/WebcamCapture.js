import React, { useState, useRef, useCallback } from 'react';
import styled from 'styled-components';
import Webcam from 'react-webcam';
import { FiCamera } from 'react-icons/fi';

const WebcamContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
`;

const StyledWebcam = styled(Webcam)`
  width: 100%;
  max-width: 500px;
  border-radius: 10px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
`;

const CaptureButton = styled.button`
  background-color: var(--primary-color);
  color: white;
  padding: 12px 24px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-weight: 500;
  margin-top: 20px;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  gap: 8px;
  
  &:hover {
    background-color: #c04b6e;
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  }
  
  &:active {
    transform: translateY(0);
  }
`;

const RetakeButton = styled.button`
  background-color: var(--secondary-color);
  color: var(--dark-color);
  padding: 12px 24px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-weight: 500;
  margin-top: 10px;
  transition: all 0.3s ease;
  
  &:hover {
    background-color: #f0a5bd;
  }
`;

const PreviewContainer = styled.div`
  margin-top: 20px;
  width: 100%;
  max-width: 500px;
`;

const ImagePreview = styled.img`
  width: 100%;
  border-radius: 10px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
`;

const WebcamCapture = ({ onCapture }) => {
  const [imgSrc, setImgSrc] = useState(null);
  const webcamRef = useRef(null);
  
  const capture = useCallback(() => {
    const imageSrc = webcamRef.current.getScreenshot();
    setImgSrc(imageSrc);
    onCapture(imageSrc);
  }, [webcamRef, onCapture]);
  
  const retake = () => {
    setImgSrc(null);
  };
  
  const videoConstraints = {
    width: 500,
    height: 375,
    facingMode: "user"
  };
  
  return (
    <WebcamContainer>
      {imgSrc ? (
        <PreviewContainer>
          <h3 className="section-title">Captured Image</h3>
          <ImagePreview src={imgSrc} alt="Captured" />
          <RetakeButton onClick={retake}>Retake Photo</RetakeButton>
        </PreviewContainer>
      ) : (
        <>
          <StyledWebcam
            audio={false}
            ref={webcamRef}
            screenshotFormat="image/jpeg"
            videoConstraints={videoConstraints}
          />
          <CaptureButton onClick={capture}>
            <FiCamera /> Capture Photo
          </CaptureButton>
        </>
      )}
    </WebcamContainer>
  );
};

export default WebcamCapture; 