import React from 'react';
import styled from 'styled-components';

const FooterContainer = styled.footer`
  margin-top: 40px;
  text-align: center;
  padding: 20px;
  color: var(--dark-color);
`;

const Copyright = styled.p`
  font-size: 14px;
`;

const FooterLinks = styled.div`
  margin-top: 15px;
  display: flex;
  justify-content: center;
  gap: 20px;
`;

const FooterLink = styled.a`
  color: var(--primary-color);
  text-decoration: none;
  font-size: 14px;
  transition: all 0.3s ease;
  
  &:hover {
    text-decoration: underline;
    color: #c04b6e;
  }
`;

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <FooterContainer>
      <Copyright>
        &copy; {currentYear} Shivalayam Makeup Studio And Academy. All rights reserved.
      </Copyright>
      <FooterLinks>
        <FooterLink href="https://shivalayammakeupstudio.netlify.app/" target="_blank" rel="noopener noreferrer">
          Main Website
        </FooterLink>
        <FooterLink href="https://shivalayammakeupstudio.netlify.app/contact" target="_blank" rel="noopener noreferrer">
          Contact Us
        </FooterLink>
        <FooterLink href="https://shivalayammakeupstudio.netlify.app/services" target="_blank" rel="noopener noreferrer">
          Services
        </FooterLink>
      </FooterLinks>
    </FooterContainer>
  );
};

export default Footer; 