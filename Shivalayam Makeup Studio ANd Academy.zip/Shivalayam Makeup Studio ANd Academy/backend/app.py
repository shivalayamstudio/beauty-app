import os
import cv2
import numpy as np
from flask import Flask, request, jsonify, render_template, send_from_directory
from flask_cors import CORS
from deepface import DeepFace
import mediapipe as mp
import base64
from PIL import Image
import io
import json
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image as ReportImage
from reportlab.lib.styles import getSampleStyleSheet

app = Flask(__name__, static_folder='static', template_folder='templates')
CORS(app)

# Create directories if they don't exist
os.makedirs('static/uploads', exist_ok=True)
os.makedirs('static/reports', exist_ok=True)

# Initialize MediaPipe Face Mesh
mp_face_mesh = mp.solutions.face_mesh
face_mesh = mp_face_mesh.FaceMesh(
    static_image_mode=True,
    max_num_faces=1,
    min_detection_confidence=0.5
)

# Celebrity database with makeup styles
celebrities = [
    {"name": "Aishwarya Rai", "image": "static/celebrities/aishwarya.jpg", "makeup_style": "Classic red lips with winged eyeliner"},
    {"name": "Deepika Padukone", "image": "static/celebrities/deepika.jpg", "makeup_style": "Bronze smokey eyes with nude lips"},
    {"name": "Priyanka Chopra", "image": "static/celebrities/priyanka.jpg", "makeup_style": "Bold brows with berry lips"},
    {"name": "Kareena Kapoor", "image": "static/celebrities/kareena.jpg", "makeup_style": "Dewy skin with pink blush and glossy lips"},
    {"name": "Alia Bhatt", "image": "static/celebrities/alia.jpg", "makeup_style": "Natural makeup with subtle highlight"}
]

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/analyze', methods=['POST'])
def analyze_face():
    if 'image' not in request.files and 'image_data' not in request.json:
        return jsonify({"error": "No image provided"}), 400
    
    if 'image' in request.files:
        # Handle file upload
        file = request.files['image']
        img_path = os.path.join('static/uploads', file.filename)
        file.save(img_path)
        img = cv2.imread(img_path)
    else:
        # Handle base64 image data
        image_data = request.json['image_data']
        image_data = image_data.split(',')[1] if ',' in image_data else image_data
        img_bytes = base64.b64decode(image_data)
        img_array = np.frombuffer(img_bytes, np.uint8)
        img = cv2.imdecode(img_array, cv2.IMREAD_COLOR)
        img_path = os.path.join('static/uploads', 'webcam_image.jpg')
        cv2.imwrite(img_path, img)
    
    # Check if face is detected
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.1, 4)
    
    if len(faces) == 0:
        return jsonify({"error": "No face detected in the image"}), 400
    
    # Gender detection
    try:
        analysis = DeepFace.analyze(img_path, actions=['gender'])
        gender = analysis[0]['dominant_gender']
        
        if gender == 'Man':
            return jsonify({"message": "We specialize in female gender"}), 200
    except Exception as e:
        print(f"Error in gender detection: {str(e)}")
        return jsonify({"error": "Error in gender detection"}), 500
    
    # Get user name from request
    user_name = request.json.get('name', '') if request.is_json else request.form.get('name', '')
    
    # Analyze facial features
    features = analyze_facial_features(img)
    
    # Find celebrity lookalike
    celebrity = find_celebrity_lookalike(img_path)
    
    # Generate makeup recommendations
    recommendations = generate_makeup_recommendations(features)
    
    # Generate report
    report_path = generate_report(img_path, user_name, features, recommendations, celebrity)
    
    response = {
        "name": user_name,
        "gender": gender,
        "features": features,
        "recommendations": recommendations,
        "celebrity": celebrity,
        "report_url": report_path.replace('static/', '/static/')
    }
    
    return jsonify(response), 200

def analyze_facial_features(img):
    # Convert to RGB for MediaPipe
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    results = face_mesh.process(img_rgb)
    
    features = {
        "skin_tone": detect_skin_tone(img),
        "skin_type": "Normal",  # Would require more advanced analysis
        "eye_color": detect_eye_color(img),
        "face_shape": detect_face_shape(results, img.shape),
        "lip_shape": "Medium",  # Simplified for demo
        "eyebrow_shape": "Natural",  # Simplified for demo
        "nose_shape": "Straight",  # Simplified for demo
        "cheekbone_height": "Medium",  # Simplified for demo
        "jawline": "Defined",  # Simplified for demo
        "forehead": "Proportional",  # Simplified for demo
        "eye_shape": "Almond",  # Simplified for demo
        "eye_distance": "Average",  # Simplified for demo
        "lip_fullness": "Medium",  # Simplified for demo
        "facial_symmetry": "Balanced"  # Simplified for demo
    }
    
    return features

def detect_skin_tone(img):
    # Convert to YCrCb color space
    img_ycrcb = cv2.cvtColor(img, cv2.COLOR_BGR2YCrCb)
    
    # Create a binary mask of skin pixels
    lower_skin = np.array([0, 135, 85], dtype=np.uint8)
    upper_skin = np.array([255, 180, 135], dtype=np.uint8)
    mask = cv2.inRange(img_ycrcb, lower_skin, upper_skin)
    
    # Apply mask to get only skin pixels
    skin = cv2.bitwise_and(img, img, mask=mask)
    
    # Calculate average color of skin pixels
    if np.sum(mask) > 0:
        skin_bgr = cv2.mean(img, mask=mask)[:3]
        # Convert BGR to HSV for better skin tone analysis
        skin_hsv = cv2.cvtColor(np.uint8([[skin_bgr]]), cv2.COLOR_BGR2HSV)[0][0]
        
        # Classify skin tone based on value (brightness)
        if skin_hsv[2] < 100:
            return "Dark"
        elif skin_hsv[2] < 150:
            return "Medium"
        else:
            return "Light"
    
    return "Medium"  # Default if no skin detected

def detect_eye_color(img):
    # This is a simplified version - would need eye detection and color analysis
    # For demo purposes, we'll return a default
    return "Brown"

def detect_face_shape(results, img_shape):
    if not results.multi_face_landmarks:
        return "Oval"  # Default
    
    face_shapes = ["Oval", "Round", "Square", "Heart", "Diamond", "Rectangle"]
    # In a real implementation, we would analyze the face landmarks
    # For demo purposes, we'll return a default
    return "Oval"

def find_celebrity_lookalike(img_path):
    # In a real implementation, we would compare facial features with celebrity database
    # For demo purposes, we'll return a random celebrity
    import random
    return random.choice(celebrities)

def generate_makeup_recommendations(features):
    recommendations = {}
    
    # Foundation recommendations based on skin tone
    if features["skin_tone"] == "Light":
        recommendations["foundation"] = "Use a light foundation with pink or neutral undertones"
    elif features["skin_tone"] == "Medium":
        recommendations["foundation"] = "Use a medium foundation with golden or neutral undertones"
    else:
        recommendations["foundation"] = "Use a deep foundation with warm undertones"
    
    # Eye makeup recommendations based on eye color
    if features["eye_color"] == "Brown":
        recommendations["eye_makeup"] = "Purple, blue, or green eyeshadows will make brown eyes pop"
    elif features["eye_color"] == "Blue":
        recommendations["eye_makeup"] = "Copper, bronze, or warm brown eyeshadows complement blue eyes"
    elif features["eye_color"] == "Green":
        recommendations["eye_makeup"] = "Purple, plum, or rusty red eyeshadows enhance green eyes"
    else:
        recommendations["eye_makeup"] = "Neutral eyeshadows work well with your eye color"
    
    # Blush recommendations based on skin tone
    if features["skin_tone"] == "Light":
        recommendations["blush"] = "Soft pink or peach blush"
    elif features["skin_tone"] == "Medium":
        recommendations["blush"] = "Warm peach or coral blush"
    else:
        recommendations["blush"] = "Deep berry or brick red blush"
    
    # Lipstick recommendations based on skin tone
    if features["skin_tone"] == "Light":
        recommendations["lipstick"] = "Soft pink, peach, or light berry lipsticks"
    elif features["skin_tone"] == "Medium":
        recommendations["lipstick"] = "Rose, mauve, or coral lipsticks"
    else:
        recommendations["lipstick"] = "Deep red, plum, or chocolate lipsticks"
    
    return recommendations

def generate_report(img_path, user_name, features, recommendations, celebrity):
    report_filename = f"report_{user_name.replace(' ', '_')}.pdf" if user_name else "makeup_report.pdf"
    report_path = os.path.join('static/reports', report_filename)
    
    doc = SimpleDocTemplate(report_path, pagesize=letter)
    styles = getSampleStyleSheet()
    elements = []
    
    # Title
    title_style = styles['Title']
    elements.append(Paragraph("Makeup Consultation Report", title_style))
    elements.append(Spacer(1, 12))
    
    # User name
    if user_name:
        elements.append(Paragraph(f"Name: {user_name}", styles['Heading2']))
        elements.append(Spacer(1, 12))
    
    # User image
    user_img = ReportImage(img_path, width=300, height=200)
    elements.append(user_img)
    elements.append(Spacer(1, 12))
    
    # Facial features
    elements.append(Paragraph("Facial Features:", styles['Heading2']))
    for feature, value in features.items():
        elements.append(Paragraph(f"{feature.replace('_', ' ').title()}: {value}", styles['Normal']))
    elements.append(Spacer(1, 12))
    
    # Makeup recommendations
    elements.append(Paragraph("Makeup Recommendations:", styles['Heading2']))
    for category, recommendation in recommendations.items():
        elements.append(Paragraph(f"{category.title()}: {recommendation}", styles['Normal']))
    elements.append(Spacer(1, 12))
    
    # Celebrity lookalike
    elements.append(Paragraph("Celebrity Lookalike:", styles['Heading2']))
    elements.append(Paragraph(f"You resemble {celebrity['name']}", styles['Normal']))
    elements.append(Paragraph(f"Recommended makeup style: {celebrity['makeup_style']}", styles['Normal']))
    
    # Build the PDF
    doc.build(elements)
    
    return report_path

if __name__ == '__main__':
    app.run(debug=True) 