import React, { useState, useRef } from 'react';
import styled from 'styled-components';
import { FiUpload } from 'react-icons/fi';

const UploadContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 30px;
  border: 2px dashed var(--secondary-color);
  border-radius: 10px;
  background-color: #fcf5f8;
  transition: all 0.3s ease;
  
  &:hover {
    border-color: var(--primary-color);
  }
`;

const UploadIcon = styled.div`
  font-size: 48px;
  color: var(--primary-color);
  margin-bottom: 20px;
`;

const UploadText = styled.p`
  margin-bottom: 20px;
  font-size: 16px;
  color: var(--dark-color);
`;

const FileInput = styled.input`
  display: none;
`;

const UploadButton = styled.button`
  background-color: var(--primary-color);
  color: white;
  padding: 12px 24px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-weight: 500;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  gap: 8px;
  
  &:hover {
    background-color: #c04b6e;
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  }
  
  &:active {
    transform: translateY(0);
  }
`;

const PreviewContainer = styled.div`
  margin-top: 20px;
  width: 100%;
  max-width: 400px;
`;

const ImagePreview = styled.img`
  width: 100%;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
`;

const ImageUpload = ({ onImageSelect }) => {
  const [preview, setPreview] = useState(null);
  const fileInputRef = useRef(null);
  
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    // Check if file is an image
    if (!file.type.match('image.*')) {
      alert('Please select an image file');
      return;
    }
    
    // Create preview
    const reader = new FileReader();
    reader.onload = () => {
      setPreview(reader.result);
    };
    reader.readAsDataURL(file);
    
    // Pass the file to parent component
    onImageSelect(file);
  };
  
  const handleButtonClick = () => {
    fileInputRef.current.click();
  };
  
  return (
    <div>
      <UploadContainer>
        <UploadIcon>
          <FiUpload />
        </UploadIcon>
        <UploadText>Upload a clear photo of your face</UploadText>
        <FileInput 
          type="file" 
          accept="image/*" 
          onChange={handleFileChange} 
          ref={fileInputRef}
        />
        <UploadButton onClick={handleButtonClick}>
          <FiUpload /> Choose Image
        </UploadButton>
      </UploadContainer>
      
      {preview && (
        <PreviewContainer>
          <h3 className="section-title">Image Preview</h3>
          <ImagePreview src={preview} alt="Preview" />
        </PreviewContainer>
      )}
    </div>
  );
};

export default ImageUpload; 