# Deploying to Netlify

This guide will help you deploy the Virtual Makeup Consultant frontend to Netlify and integrate it with the existing Shivalayam Makeup Studio website.

## Prerequisites

- A GitHub repository containing your project
- A Netlify account (sign up at [netlify.com](https://netlify.com))

## Deployment Steps

### 1. Push your code to GitHub

Make sure your code is pushed to a GitHub repository.

### 2. Connect to Netlify

1. Log in to your Netlify account
2. Click "New site from Git"
3. Select GitHub as your Git provider
4. Authorize Netlify to access your GitHub account
5. Select your repository

### 3. Configure build settings

- **Branch to deploy**: `main` (or `master`)
- **Build command**: `npm run build`
- **Publish directory**: `build`

### 4. Configure environment variables

Add the following environment variable:
- Key: `REACT_APP_API_URL`
- Value: `https://shivalayam-makeup-consultant-api.herokuapp.com` (or your backend URL)

### 5. Deploy the site

Click "Deploy site" and wait for the build to complete.

### 6. Set up a custom domain (optional)

1. Go to "Site settings" > "Domain management"
2. Click "Add custom domain"
3. Enter your domain (e.g., `makeup-consultant.shivalayammakeupstudio.com`)
4. Follow the instructions to configure your DNS settings

## Integration with Main Website

### Option 1: Subdomain

Create a subdomain (e.g., `makeup-consultant.shivalayammakeupstudio.netlify.app`) and point it to your Netlify site.

### Option 2: Path-based routing

If you want to host the application under a path of the main website (e.g., `shivalayammakeupstudio.netlify.app/makeup-consultant`), you'll need to:

1. Update the `homepage` field in your `package.json` to `/makeup-consultant`
2. Configure Netlify to serve the app from that path

### Option 3: iFrame integration

You can embed the application in an iFrame on the main website:

```html
<iframe 
  src="https://your-netlify-app-url.netlify.app" 
  title="Virtual Makeup Consultant" 
  width="100%" 
  height="800px" 
  frameborder="0"
></iframe>
```

## Adding Navigation Links

Add the navigation link to the main website using the provided `integration-nav-snippet.html` file. Replace `[YOUR_VIRTUAL_MAKEUP_CONSULTANT_URL]` with your Netlify URL. 