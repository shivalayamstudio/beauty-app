import React, { useState } from 'react';
import styled from 'styled-components';
import { ThreeDots } from 'react-loader-spinner';
import { FiExternalLink } from 'react-icons/fi';
import ImageUpload from './components/ImageUpload';
import WebcamCapture from './components/WebcamCapture';
import NameInput from './components/NameInput';
import Results from './components/Results';
import Header from './components/Header';
import Footer from './components/Footer';
import './App.css';

const AppContainer = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
`;

const MainContent = styled.main`
  background-color: white;
  border-radius: 10px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  padding: 30px;
  margin-top: 20px;
`;

const TabContainer = styled.div`
  display: flex;
  margin-bottom: 20px;
`;

const Tab = styled.button`
  padding: 10px 20px;
  background-color: ${props => props.active ? 'var(--primary-color)' : 'var(--secondary-color)'};
  color: ${props => props.active ? 'white' : 'var(--dark-color)'};
  border: none;
  border-radius: 5px 5px 0 0;
  cursor: pointer;
  margin-right: 5px;
  font-weight: 500;
  transition: all 0.3s ease;

  &:hover {
    background-color: ${props => props.active ? 'var(--primary-color)' : '#f0a5bd'};
  }
`;

const LoadingContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 40px;
`;

const LoadingText = styled.p`
  margin-top: 20px;
  font-size: 18px;
  color: var(--primary-color);
`;

const ErrorMessage = styled.div`
  background-color: #ffebee;
  color: var(--error-color);
  padding: 15px;
  border-radius: 5px;
  margin-bottom: 20px;
  border-left: 4px solid var(--error-color);
`;

const WebsiteBanner = styled.div`
  background-color: var(--secondary-color);
  color: var(--dark-color);
  padding: 10px;
  border-radius: 5px;
  margin-bottom: 20px;
  text-align: center;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
`;

const WebsiteLink = styled.a`
  color: var(--primary-color);
  font-weight: 600;
  text-decoration: none;
  display: flex;
  align-items: center;
  gap: 5px;
  
  &:hover {
    text-decoration: underline;
  }
`;

function App() {
  const [activeTab, setActiveTab] = useState('upload');
  const [image, setImage] = useState(null);
  const [name, setName] = useState('');
  const [showNameInput, setShowNameInput] = useState(false);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState(null);
  const [error, setError] = useState(null);

  const handleImageSelect = (selectedImage) => {
    setImage(selectedImage);
    setError(null);
    analyzeImage(selectedImage);
  };

  const analyzeImage = async (selectedImage) => {
    setLoading(true);
    setResults(null);
    
    try {
      // Create form data for the API request
      const formData = new FormData();
      
      if (selectedImage instanceof File) {
        formData.append('image', selectedImage);
      } else {
        // For base64 image data from webcam
        const response = await fetch('/api/analyze', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ 
            image_data: selectedImage,
            name: name 
          }),
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw new Error(data.error || 'Failed to analyze image');
        }
        
        if (data.message === "We specialize in female gender") {
          setError("We specialize in female gender makeup. Please upload a female face image.");
          setLoading(false);
          return;
        }
        
        // If female, show name input
        setShowNameInput(true);
        setLoading(false);
        return;
      }
      
      const response = await fetch('/api/analyze', {
        method: 'POST',
        body: formData,
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to analyze image');
      }
      
      if (data.message === "We specialize in female gender") {
        setError("We specialize in female gender makeup. Please upload a female face image.");
        setLoading(false);
        return;
      }
      
      // If female, show name input
      setShowNameInput(true);
      setLoading(false);
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  };

  const handleNameSubmit = async (submittedName) => {
    setName(submittedName);
    setLoading(true);
    
    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          image_data: image,
          name: submittedName
        }),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to generate report');
      }
      
      setResults(data);
      setShowNameInput(false);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const resetApp = () => {
    setImage(null);
    setName('');
    setShowNameInput(false);
    setResults(null);
    setError(null);
  };

  return (
    <AppContainer>
      <Header />
      
      <MainContent>
        <WebsiteBanner>
          This is the Virtual Makeup Consultant tool. Visit our 
          <WebsiteLink href="https://shivalayammakeupstudio.netlify.app/" target="_blank" rel="noopener noreferrer">
            main website <FiExternalLink />
          </WebsiteLink>
          for more services and information.
        </WebsiteBanner>
        
        {error && <ErrorMessage>{error}</ErrorMessage>}
        
        {!loading && !showNameInput && !results && (
          <>
            <TabContainer>
              <Tab 
                active={activeTab === 'upload'} 
                onClick={() => setActiveTab('upload')}
              >
                Upload Image
              </Tab>
              <Tab 
                active={activeTab === 'webcam'} 
                onClick={() => setActiveTab('webcam')}
              >
                Use Webcam
              </Tab>
            </TabContainer>
            
            {activeTab === 'upload' ? (
              <ImageUpload onImageSelect={handleImageSelect} />
            ) : (
              <WebcamCapture onCapture={handleImageSelect} />
            )}
          </>
        )}
        
        {loading && (
          <LoadingContainer>
            <ThreeDots 
              height="80" 
              width="80" 
              radius="9"
              color="var(--primary-color)" 
              ariaLabel="loading"
            />
            <LoadingText>Analyzing your image...</LoadingText>
          </LoadingContainer>
        )}
        
        {showNameInput && !loading && (
          <NameInput onSubmit={handleNameSubmit} />
        )}
        
        {results && !loading && (
          <Results results={results} onReset={resetApp} />
        )}
      </MainContent>
      
      <Footer />
    </AppContainer>
  );
}

export default App; 